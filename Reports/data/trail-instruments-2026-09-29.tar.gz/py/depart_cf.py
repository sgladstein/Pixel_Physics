#!/usr/bin/env python3
"""Post hoc (not registered): the door read, reach 2 and 6 at the nest centre on
row 95, from the plane sample at or before each empty ant's departure from the
nest band (at_nest >= 0.5 -> < 0.5, workers id%4==0 excluded), live vs cf=gate."""
import sys, csv, bisect, collections, statistics as st
LOG, CSVDIR = sys.argv[1], sys.argv[2]
prof = collections.defaultdict(dict); meta = {}
for line in open(LOG):
    if not line.startswith('BTRAIL '): continue
    kv = dict(t.split('=', 1) for t in line.split()[1:])
    if kv['arm'] != 'self' or kv['ch'] != 'B' or kv['y'] != '95': continue
    if kv['kind'] == 'live' or kv['rule'] == 'gate':
        prof[(int(kv['seed']), int(kv['gap']), kv['kind'])][int(kv['frame'])] = list(map(int, kv['prof'].split(',')))
        meta[(int(kv['seed']), int(kv['gap']))] = (int(kv['x0']), int(kv['nest']))
def g(p, x0, nest, r):
    bF = max(p[nest + k - x0] for k in ((1, 2) if r == 2 else (6,))); bA = max(p[nest - k - x0] for k in ((1, 2) if r == 2 else (6,)))
    return (bF - bA) / (bF + bA + 1024)
for gap in (90, 140):
    tot = collections.Counter(); per = []
    for s in range(1, 9):
        x0, nest = meta[(s, gap)]
        path = f'{CSVDIR}/trailfollow-decisions-seed{s}-gap{gap}-self-cf.csv'
        rd = csv.reader(open(path)); h = next(rd); ix = {k: i for i, k in enumerate(h)}
        prev = {}; deps = []
        for row in rd:
            i = int(row[ix['id']]); a = float(row[ix['at_nest']])
            if i % 4 and prev.get(i, 0) >= 0.5 and a < 0.5 and float(row[ix['fill']]) == 0.0:
                deps.append(int(row[ix['frame']]))
            prev[i] = a
        c = collections.Counter()
        for kind in ('live', 'cf'):
            P = prof[(s, gap, kind)]; fr = sorted(P)
            for d in deps:
                j = bisect.bisect_right(fr, d) - 1
                if j < 0: continue
                p = P[fr[j]]; c[(kind, 'n')] += 1
                c[(kind, 'g2')] += g(p, x0, nest, 2) > 0.1; c[(kind, 'g6')] += g(p, x0, nest, 6) > 0.1
        per.append((s, c)); tot += c
        print(f"  seed {s} gap {gap}: departures {c[('live','n')]}  g6>0.1 live {c[('live','g6')]/max(1,c[('live','n')]):.0%} gate {c[('cf','g6')]/max(1,c[('cf','n')]):.0%}   g2>0.1 live {c[('live','g2')]/max(1,c[('live','n')]):.0%} gate {c[('cf','g2')]/max(1,c[('cf','n')]):.0%}")
    up6 = sum(c[('cf','g6')] / c[('cf','n')] > c[('live','g6')] / c[('live','n')] for s, c in per)
    print(f"  gap {gap} pooled: g6>0.1 live {tot[('live','g6')]/tot[('live','n')]:.0%} gate {tot[('cf','g6')]/tot[('cf','n')]:.0%}; g2>0.1 live {tot[('live','g2')]/tot[('live','n')]:.0%} gate {tot[('cf','g2')]/tot[('cf','n')]:.0%}; gate above live on g6 in {up6}/8 seeds")
