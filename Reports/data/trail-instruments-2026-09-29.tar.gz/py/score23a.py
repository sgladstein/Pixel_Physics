#!/usr/bin/env python3
"""Score §23a's P0.6-P0.10 on the cf runs. Self arm, late half (frame > 12000),
row surface+1 (95) unless named. Keys: (seed, gap, kind, rule)."""
import sys, re, csv, math, statistics as st, collections, subprocess
LOG = sys.argv[1]; CSVDIR = sys.argv[2]
LATE = 12000; ROW = 95
prof = collections.defaultdict(list)   # (seed,gap,kind,rule,y) -> [(frame, [B])]
meta = {}
for line in open(LOG):
    if not line.startswith('BTRAIL '): continue
    kv = dict(t.split('=', 1) for t in line.split()[1:])
    if kv['arm'] != 'self' or kv['ch'] != 'B': continue
    f = int(kv['frame'])
    if f <= LATE: continue
    k = (int(kv['seed']), int(kv['gap']), kv['kind'], kv['rule'], int(kv['y']))
    prof[k].append((f, list(map(int, kv['prof'].split(',')))))
    meta[(k[0], k[1])] = (int(kv['x0']), int(kv['nest']), int(kv['target']))
keys = sorted({k[:4] for k in prof})
print('keys', len(keys), 'seeds', sorted({k[0] for k in keys}), 'gaps', sorted({k[1] for k in keys}), 'kind/rule', sorted({k[2:] for k in keys}))
print('samples per key', collections.Counter(len(v) for v in prof.values()))
seeds = sorted({k[0] for k in keys}); gaps = sorted({k[1] for k in keys})
def plane(s, g, kind, rule): return {y: prof[(s, g, kind, rule, y)] for y in range(91, 96)}
def rows_key(kind, rule): return ('live', '-') if kind == 'live' else ('cf', rule)

# P0.7: west-of-door B (5 band rows, x < nest_lo) and door B (nest_lo..nest_hi, row 95).
print('\nP0.7  west of door (band, time-mean sum) and door B (row 95, time-mean), gate vs live')
for g in gaps:
    wk = dk = 0; lines = []
    for s in seeds:
        x0, nest, tgt = meta[(s, g)]; nlo, nhi = nest - 2, nest + 2
        def west(kind, rule):
            P = plane(s, g, *rows_key(kind, rule)); tot = 0; n = 0
            for y, samples in P.items():
                for f, p in samples:
                    tot += sum(p[: nlo - x0]); n += 1
            return tot / max(1, n) * 5
        def door(kind, rule):
            samples = prof[(s, g, *rows_key(kind, rule), ROW)]
            return st.mean(sum(p[nlo - x0: nhi - x0 + 1]) / 5 for f, p in samples)
        wl, wg, dl, dg = west('live', '-'), west('cf', 'gate'), door('live', '-'), door('cf', 'gate')
        cw = 1 - wg / wl if wl else float('nan'); cd = 1 - dg / dl if dl else float('nan')
        wk += cw >= 0.90; dk += cd >= 0.50
        lines.append(f'  seed {s} gap {g}: west {wl:9.0f} -> {wg:9.0f} ({cw:+.1%} cut)   door {dl:7.0f} -> {dg:7.0f} ({cd:+.1%} cut)')
    print('\n'.join(lines)); print(f'  gap {g}: west cut >= 90% on {wk}/8 (bar 7/8); door cut >= 50% on {dk}/8 (bar 6/8)')

# P0.8/P0.9: door gradients, medians over late samples. g = (bF-bA)/(bF+bA+1024).
def grads(s, g, kind, rule):
    x0, nest, tgt = meta[(s, g)]; sgn = 1 if tgt > nest else -1
    g2s, g6s = [], []
    for f, p in prof[(s, g, *rows_key(kind, rule), ROW)]:
        at = lambda x: p[x - x0]
        bF = max(at(nest + sgn), at(nest + 2 * sgn)); bA = max(at(nest - sgn), at(nest - 2 * sgn))
        g2s.append((bF - bA) / (bF + bA + 1024))
        bF6, bA6 = at(nest + 6 * sgn), at(nest - 6 * sgn)
        g6s.append((bF6 - bA6) / (bF6 + bA6 + 1024))
    return st.median(g2s), st.median(g6s)
print('\nP0.8/P0.9  door gradient medians (g2, g6): live | gate | odo32 | all rules g6')
rules = ['gate', 'odo16', 'odo24', 'odo32', 'odo48', 'step32']
beat = {r: {g: 0 for g in gaps} for r in rules}
for g in gaps:
    a = b = c = d = 0
    for s in seeds:
        L = grads(s, g, 'live', '-'); G = grads(s, g, 'cf', 'gate'); O = grads(s, g, 'cf', 'odo32')
        R = {r: grads(s, g, 'cf', r)[1] for r in rules}
        for r in rules:
            if r != 'gate' and R[r] > R['gate']: beat[r][g] += 1
        a += G[1] > L[1]; b += G[1] > 0.3; c += G[0] > L[0]; d += O[1] < G[1]
        print(f'  seed {s} gap {g}: live {L[0]:+.3f} {L[1]:+.3f} | gate {G[0]:+.3f} {G[1]:+.3f} | odo32 {O[0]:+.3f} {O[1]:+.3f} | ' + ' '.join(f'{r} {R[r]:+.3f}' for r in rules))
    print(f'  gap {g}: P0.8 g6 gate>live {a}/8 (7/8), gate g6>0.3 {b}/8 (6/8), g2 gate>live {c}/8 (6/8); P0.9 odo32 g6<gate {d}/8 (7/8)')
print('  seeds on which each rule beats gate on g6:', {r: beat[r] for r in rules if r != 'gate'})

# P0.10: food-side B at reach 6 against frames since the last return.
def spearman(xs, ys):
    def rank(v):
        o = sorted(range(len(v)), key=lambda i: v[i]); r = [0.0] * len(v); i = 0
        while i < len(v):
            j = i
            while j + 1 < len(v) and v[o[j + 1]] == v[o[i]]: j += 1
            for k in range(i, j + 1): r[o[k]] = (i + j) / 2
            i = j + 1
        return r
    rx, ry = rank(xs), rank(ys); mx, my = st.mean(rx), st.mean(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry)); den = math.sqrt(sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry))
    return num / den if den else float('nan')
print('\nP0.10  Spearman(food-side B at reach 6, frames since last return)')
for g in gaps:
    kg = kl = 0
    for s in seeds:
        path = f'{CSVDIR}/trailfollow-decisions-seed{s}-gap{g}-self-cf.csv'
        rd = csv.reader(open(path)); h = next(rd); ix = {k: i for i, k in enumerate(h)}
        last = {}; returns = []
        for row in rd:
            i = row[ix['id']]; tl = row[ix['trip_load']] == '1'
            if last.get(i) and not tl and row[ix['at_nest']] not in ('0', '0.0000', '0.0'):
                returns.append(int(row[ix['frame']]))
            last[i] = tl
        returns.sort()
        x0, nest, tgt = meta[(s, g)]; sgn = 1 if tgt > nest else -1
        def rho(kind, rule):
            xs, ys = [], []
            for f, p in prof[(s, g, *rows_key(kind, rule), ROW)]:
                prev = [r for r in returns if r <= f]
                if not prev: continue
                xs.append(p[nest + 6 * sgn - x0]); ys.append(f - prev[-1])
            return spearman(xs, ys), len(xs)
        (rg, n), (rl, _) = rho('cf', 'gate'), rho('live', '-')
        kg += rg < -0.3; kl += abs(rl) <= 0.2
        print(f'  seed {s} gap {g}: returns {len(returns)}  gate rho {rg:+.3f}  live rho {rl:+.3f}  (n {n})')
    print(f'  gap {g}: gate rho < -0.3 on {kg}/8 (6/8); live |rho| <= 0.2 on {kl}/8 (6/8)')
