#!/bin/bash
# Stage 0 counterfactual lay rules on today's live paths (tf-s0a). Unlimited
# pile, gaps 90 and 140, seeds 1-8, self and hand. Readouts are registered in
# ant-scenes §23a BEFORE these logs are opened.
cd /home/user/runs/s0
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
T=../tf-s0a
U="ants=20 food=400 refill=400"
CF="cf=gate,odo16,odo24,odo32,odo48,step32 btrail btrailevery=100 shadow"
run() { local gap=$1 s0=$2
  $T mode=gap gate=shipped frames=24000 near=10 arms=self,hand gaps=$gap $U $CF decisioncsv dwide dtag=cf seeds=4 seed0=$s0 > cf-$gap-$s0.log 2>&1
  echo "cf $gap $s0 exit $? $(date +%H:%M)"; }
run 90 1 & run 90 5 & run 140 1 & run 140 5 &
wait
mkdir -p csvcf && mv /tmp/trailfollow-decisions-seed*-cf.csv csvcf/ 2>/dev/null
echo cf-done
