#!/bin/bash
# Stage 0 G0 checks on the instrumented build (tf-s0a).
cd /home/user/runs/s0
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
T=../tf-s0a
P="ants=20 food=30 refill=6000"; U="ants=20 food=400 refill=400"
B="mode=gap gate=shipped frames=24000 near=10"
# G0.1 identity: main's b518p-90 seeds 1-8, same command, new binary.
( $T $B arms=self gaps=90 $P decisioncsv dtag=s0id seeds=8 seed0=1 > id-p90.log 2>&1; echo "id done $(date +%H:%M)" ) &
# G0.2/G0.5 shadow + cf=brain, three arms, both gaps, unlimited pile, 8000 frames.
( $T mode=gap gate=shipped frames=8000 near=10 arms=self,mute,hand gaps=90,140 $U shadow cf=brain,gate,odo32,step32 btrail btrailevery=1000 seeds=2 seed0=1 > shadow-u.log 2>&1; echo "shadow done $(date +%H:%M) exit $?" ) &
# The same without any instrument, to show the instruments change nothing.
( $T mode=gap gate=shipped frames=8000 near=10 arms=self,mute,hand gaps=90,140 $U seeds=2 seed0=1 > plain-u.log 2>&1; echo "plain done $(date +%H:%M)" ) &
# Red control: a dropped deposit must trip the check.
( $T mode=gap gate=shipped frames=2000 near=10 arms=self gaps=90 $U shadow shadowfault=10 seeds=1 seed0=1 > fault.log 2>&1; echo "fault exit $? $(date +%H:%M)" ) 
wait
echo g0-done
