Pre-ship checks for PIXEL_PHYSICS_FOOD_TRAIL=lay (Reports/ant-scenes-2026-09-23.md s23c), 2026-09-30.
terrain/  ascii's "ants: the foraging loop" scene with the worldgen seed as an argument
          (zz_antterrain.rs, a temporary example, not committed; build it by copying into
          examples/), seeds 1-12, 24,000 frames, RAYON_NUM_THREADS=1, off vs lay.
          ant<seed>-<arm>.txt keep the TERRAIN, CENSUS and GONE rows (the ANT rows every
          50 frames are dropped for size; rerun trace12.sh to regenerate them, byte-identical).
          gone.py reads deaths by place from the full files.
seed1/    seed 1 with every ANT row (nearest food, its material, trail B at the head, held spoil), to frame 18,000.
lab/      labforage scenario=played_bed frames=120000, seeds 1-24, off vs lay:
          python3 scripts/labpair.py lab off lay. ascii-*.txt: the frame-cost pairs.
