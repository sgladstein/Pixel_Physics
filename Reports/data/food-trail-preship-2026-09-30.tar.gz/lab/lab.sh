#!/bin/bash
# Lab-box pre-ship check for FOOD_TRAIL=lay (lf-s1a). Run from the repo root
# (labforage reads assets/); the bed's env must NOT be set.
cd /home/user/Pixel_Physics
unset PIXEL_PHYSICS_COLONY_SPACING PIXEL_PHYSICS_STACK_DEPTH PIXEL_PHYSICS_BUD_SITE
export RAYON_NUM_THREADS=1
job() { local arm=$1 s=$2
  if [ $arm = lay ]; then export PIXEL_PHYSICS_FOOD_TRAIL=lay; else unset PIXEL_PHYSICS_FOOD_TRAIL; fi
  /home/user/runs/lf-s1a scenario=played_bed frames=120000 seed=$s > /home/user/runs/labs1/$arm-$s.log 2>&1
  echo "$arm $s exit $? $(date +%H:%M)"; }
export -f job
for s in $(seq 1 24); do for a in off lay; do echo "$a $s"; done; done | xargs -P 4 -L 1 bash -c 'job "$@"' _
echo lab-done
