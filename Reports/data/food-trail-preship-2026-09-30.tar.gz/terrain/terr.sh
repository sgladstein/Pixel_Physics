#!/bin/bash
# Generated-terrain check of the lay rule: ascii's foraging scene, worldgen
# seeds 1-12, 24,000 frames, off vs lay, RAYON_NUM_THREADS=1 (counters
# downstream of parallel.rs depend on the thread count).
cd /home/user/runs/terr
export RAYON_NUM_THREADS=1
unset PIXEL_PHYSICS_COLONY_SPACING PIXEL_PHYSICS_STACK_DEPTH PIXEL_PHYSICS_BUD_SITE
job() { local arm=$1 s=$2 f=/home/user/runs/terr/$1-$2.txt
  if grep -q "frame=24000 " $f 2>/dev/null; then echo "$arm $s skip"; return; fi
  if [ $arm = lay ]; then export PIXEL_PHYSICS_FOOD_TRAIL=lay; else unset PIXEL_PHYSICS_FOOD_TRAIL; fi
  ../zz-terr seed=$s frames=24000 > $f 2>&1; echo "$arm $s exit $? $(date +%H:%M)"; }
export -f job
for s in $(seq 1 12); do for a in off lay; do echo "$a $s"; done; done | xargs -P 3 -L 1 bash -c 'job "$@"' _
echo terr-done
