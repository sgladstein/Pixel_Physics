#!/bin/bash
# Per-ant trace of the terrain check: every seed, both arms, ANT rows every 50 frames and GONE rows.
cd /home/user/runs/terr
export RAYON_NUM_THREADS=1
unset PIXEL_PHYSICS_COLONY_SPACING PIXEL_PHYSICS_STACK_DEPTH PIXEL_PHYSICS_BUD_SITE
job() { local arm=$1 s=$2 f=/home/user/runs/terr/ant$2-$1.txt
  if grep -q "^TERRAIN.*frame=24000 " $f 2>/dev/null; then echo "$arm $s skip"; return; fi
  if [ $arm = lay ]; then export PIXEL_PHYSICS_FOOD_TRAIL=lay; else unset PIXEL_PHYSICS_FOOD_TRAIL; fi
  ../zz-terr3 seed=$s frames=24000 trace=50 > $f 2>&1; echo "$arm $s exit $? $(date +%H:%M)"; }
export -f job
for s in $(seq 2 12); do for a in off lay; do echo "$a $s"; done; done | xargs -P 4 -L 1 bash -c 'job "$@"' _
echo trace12-done
