import re,sys,collections
def parse(fn):
    ants=collections.defaultdict(list); gone=[]
    for line in open(fn):
        if line.startswith('ANT '):
            d=dict(kv.split('=') for kv in line.split()[1:])
            ants[int(d['id'])].append(d)
        elif line.startswith('GONE '):
            m=re.search(r'id=(\d+) last: ANT (.*)',line)
            d=dict(kv.split('=') for kv in m.group(2).split())
            gone.append(d)
    return ants,gone
tot=collections.Counter()
print("seed arm | deaths home(x<120) away | home&starved(e<=5) | home deaths never-trip | ant-frames home-empty-hungry(e<200,crop0,x<120)")
rows={}
for s in range(1,13):
    for a in ('off','lay'):
        ants,gone=parse(f'ant{s}-{a}.txt')
        home=[g for g in gone if int(g['x'])<120]; away=[g for g in gone if int(g['x'])>=120]
        hs=[g for g in home if float(g['e'])<=5]
        nt=[g for g in home if not any(r['trip']=='1' for r in ants[int(g['id'])])]
        hh=sum(1 for rs in ants.values() for r in rs if int(r['x'])<120 and float(r['e'])<200 and float(r['crop'])==0)
        rows[(s,a)]=(len(gone),len(home),len(away),len(hs),len(nt),hh)
        tot[a+'g']+=len(gone); tot[a+'h']+=len(home); tot[a+'hs']+=len(hs); tot[a+'hh']+=hh
    o,l=rows[(s,'off')],rows[(s,'lay')]
    print(f"s{s:2} off {o}  lay {l}")
print(dict(tot))
def sgn(i):
    up=sum(1 for s in range(1,13) if rows[(s,'lay')][i]>rows[(s,'off')][i]); dn=sum(1 for s in range(1,13) if rows[(s,'lay')][i]<rows[(s,'off')][i]); return up,dn
for i,n in enumerate(['gone','home','away','home_starved','home_never_trip','hungry_home_frames']): print(n,'lay higher/lower',sgn(i))
