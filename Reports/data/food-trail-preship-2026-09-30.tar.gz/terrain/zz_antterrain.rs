//! TEMPORARY, not for commit: `ascii`'s "ants: the foraging loop" scene
//! (generated terrain, a nest patch, six trees, strewn litter, 55 ants) with
//! the worldgen seed as an argument, to check the food trail's lay rule on
//! terrain the colony bed never sees. `seed=N frames=F`; the food-trail switch
//! comes from `PIXEL_PHYSICS_FOOD_TRAIL` as everywhere else.
use pixel_physics::sim::chunk::Rect;
use pixel_physics::sim::material;
use pixel_physics::sim::pheromone::Channel;
use pixel_physics::sim::{parallel, Cell, World};

fn main() {
    let mut seed = 1u64;
    let mut frames = 24000usize;
    let mut trace = 0usize;
    for a in std::env::args().skip(1) {
        let (k, v) = a.split_once('=').expect("key=value");
        match k {
            "seed" => seed = v.parse().expect("seed"),
            "frames" => frames = v.parse().expect("frames"),
            "trace" => trace = v.parse().expect("trace"),
            other => panic!("unknown arg {other}"),
        }
    }
    let ft = std::env::var("PIXEL_PHYSICS_FOOD_TRAIL").unwrap_or_else(|_| "unset".into());
    let (w, h) = (512i32, 120i32);
    let mut world = World::new(Rect::new(0, 0, w - 1, h - 1));
    let nest = world.materials.id_of("nest").expect("nest");
    let (presets, err) = pixel_physics::worldgen::WorldgenPresets::load();
    if let Some(e) = err {
        panic!("worldgen presets unavailable: {e}");
    }
    let params = presets.get(&presets.default_name()).expect("default preset");
    pixel_physics::worldgen::generate(&mut world, pixel_physics::worldgen::Spec::Generated { params, seed });
    let surface = |world: &World, x: i32| -> i32 {
        (0..h)
            .find(|&y| {
                let c = world.get(x, y);
                c.organism_id() == 0 && matches!(world.materials.kind(c.material), material::MaterialKind::Solid | material::MaterialKind::Powder)
            })
            .unwrap_or(h - 1)
    };
    for x in 16..90 {
        let sy = surface(&world, x);
        world.set(x, sy, Cell::new(nest, 0).with_attached(true));
    }
    for i in 0..6 {
        let x = 230 + i * 40;
        let sy = surface(&world, x);
        world.plant_tree(x, sy - 1);
    }
    for _ in 0..2400 {
        parallel::step(&mut world);
        world.step_active_sites();
        world.step_fields();
    }
    {
        let litter = world.materials.id_of("litter").expect("litter");
        for x in (200..470).step_by(3) {
            let sy = surface(&world, x);
            if sy > 0 && world.is_empty(x, sy - 1) {
                world.set(x, sy - 1, Cell::new(litter, (x as u8) % 4));
            }
        }
    }
    let mut colony = None;
    for i in 0..55 {
        let ax = 24 + i * 4;
        let sy = surface(&world, ax);
        if let Some(site) = pixel_physics::sim::creature::plant_creature_seed_in(&mut world, ax, sy - 1, "ant", colony) {
            colony = colony.or_else(|| pixel_physics::sim::creature::colony_of_site(&world, &site));
            world.schedule_active_site(site);
        }
    }
    let starved_ix = pixel_physics::sim::organism::DeathCause::Starved.index();
    let report = |world: &World, f: usize| {
        let st = world.creature_stats;
        let b: u64 = (0..w).flat_map(|x| (0..h).map(move |y| (x, y))).map(|(x, y)| world.pheromone_at(Channel::B, x, y) as u64).sum();
        let west: u64 = (0..90).flat_map(|x| (0..h).map(move |y| (x, y))).map(|(x, y)| world.pheromone_at(Channel::B, x, y) as u64).sum();
        println!(
            "TERRAIN seed={seed} ft={ft} frame={f} trips={} depth_max={} deliveries={} pickups={} eats={} births={} deaths={} starved={} alive={} emit_j={:.0} b_plane={b} b_home_side={west}",
            st.forage_trips,
            st.forage_depth_max,
            st.deliveries,
            st.pickups,
            st.eats,
            st.births,
            st.deaths,
            world.deaths_by_cause[starved_ix],
            world.live_creature_count(),
            st.emit_energy,
        );
    };
    // Census for the trace: food worth left by region, and where the ants are,
    // how many carry, and their energy.
    let census = |world: &World, f: usize| {
        let mut food = [0.0f64; 3];
        for x in 0..w {
            for y in 0..h {
                let v = pixel_physics::sim::creature::food_value(world, world.get(x, y)) as f64;
                if v > 0.0 {
                    food[if x < 120 { 0 } else if x < 200 { 1 } else { 2 }] += v;
                }
            }
        }
        let (mut n, mut carrying, mut home, mut mid, mut stand, mut e_sum) = (0, 0, 0, 0, 0, 0.0f32);
        let mut xs: Vec<i32> = Vec::new();
        for id in world.live_organism_ids() {
            let Some(st) = world.organism(id) else { continue };
            if world.species.get(st.species).creature.is_none() {
                continue;
            }
            let Some(&(hx, _)) = st.chain.first() else { continue };
            n += 1;
            e_sum += st.energy;
            xs.push(hx);
            if st.crop.is_some_and(|c| c.worth() > 0.0) {
                carrying += 1;
            }
            if hx < 120 {
                home += 1
            } else if hx < 200 {
                mid += 1
            } else {
                stand += 1
            }
        }
        xs.sort();
        println!(
            "CENSUS seed={seed} ft={ft} frame={f} food_home={:.0} food_mid={:.0} food_stand={:.0} ants={n} carrying={carrying} at_home={home} mid={mid} at_stand={stand} mean_energy={:.0} xs={:?}",
            food[0], food[1], food[2], e_sum / n.max(1) as f32, xs
        );
    };
    let mut last: std::collections::HashMap<u32, String> = std::collections::HashMap::new();
    for f in 1..=frames {
        parallel::step(&mut world);
        world.step_active_sites();
        world.step_fields();
        world.step_pheromones();
        if trace > 0 && f % trace == 0 {
            let mut now = std::collections::HashMap::new();
            for id in world.live_organism_ids() {
                let Some(st) = world.organism(id) else { continue };
                if world.species.get(st.species).creature.is_none() {
                    continue;
                }
                let Some(&(hx, hy)) = st.chain.first() else { continue };
                let mut nf = (99i32, 0i32, 0i32);
                for dy in -30i32..=30 {
                    for dx in -30i32..=30 {
                        let (cx, cy) = (hx + dx, hy + dy);
                        if cx < 0 || cy < 0 || cx >= w || cy >= h {
                            continue;
                        }
                        let d = dx.abs().max(dy.abs());
                        let c = world.get(cx, cy);
                        if d < nf.0 && c.organism_id() == 0 && pixel_physics::sim::creature::food_value(&world, c) > 0.0 {
                            nf = (d, cx, cy);
                        }
                    }
                }
                let bh = world.pheromone_at(Channel::B, hx, hy);
                let nfm = if nf.0 < 99 { world.materials.get(world.get(nf.1, nf.2).material).name.clone() } else { "-".into() };
                let nfa = if nf.0 < 99 { world.get(nf.1, nf.2).attached() } else { false };
                let sp = st.spoil.map(|sp| format!("{}{}", world.materials.get(sp.cell.material).name, if sp.store { "S" } else { "" })).unwrap_or_else(|| "-".into());
                let row = format!(
                    "ANT f={f} id={id} x={hx} y={hy} e={:.0} crop={:.1} trip={} src={} since={} born={} nf={} nfx={} nfy={} bh={bh} nfm={nfm} nfa={} spoil={sp}",
                    st.energy,
                    st.crop.map(|c| c.worth()).unwrap_or(0.0),
                    st.trip_load as u8,
                    st.trip_src,
                    st.since_trip,
                    st.born_frame,
                    nf.0,
                    nf.1,
                    nf.2,
                    nfa as u8
                );
                println!("{row}");
                now.insert(id, row);
            }
            for (id, row) in &last {
                if !now.contains_key(id) {
                    println!("GONE f={f} id={id} last: {row}");
                }
            }
            last = now;
        }
        if f % 2000 == 0 {
            report(&world, f);
            census(&world, f);
        }
    }
}
