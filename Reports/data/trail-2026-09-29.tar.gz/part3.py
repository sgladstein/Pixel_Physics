"""Part 3: how often laden trips refresh trail B at the door, and what B reads when a fed forager leaves.
usage: part3.py dep-90-<arm>.tsv  (reads its .arrivals too)
Laden arrival: at_nest 0->1 on a row with leg laden, drive NaN, trip_load 1 (departures.py); the same ant again within
200 frames is the same arrival (door-edge flicker) and is dropped. Intervals are between successive arrivals of any
ant, per seed, from the first arrival to the last."""
import sys, csv, collections, statistics as st, math
p = sys.argv[1]
arr = collections.defaultdict(list)
for r in csv.DictReader(open(p + '.arrivals'), delimiter='\t'):
    arr[(r['gap'], r['seed'], r['arm'])].append((int(r['frame']), int(r['id'])))
print(f'{p}: arrival keys {len(arr)}')
allint = []
for k in sorted(arr, key=lambda k: int(k[1])):
    last = {}; kept = []
    for fr, i in sorted(arr[k]):
        if i in last and fr - last[i] < 200: last[i] = fr; continue
        last[i] = fr; kept.append(fr)
    iv = [b - a for a, b in zip(kept, kept[1:])]
    allint += iv
    if iv:
        s = sorted(iv)
        print(f'  seed {k[1]:>2}: arrivals {len(arr[k]):3} deduped {len(kept):3}  first {kept[0]:5} last {kept[-1]:5}  interval median {st.median(s):5.0f} p75 {s[3*len(s)//4]:5} p90 {s[9*len(s)//10]:5} max {s[-1]:5}  '
              f'time in gaps >270: {sum(x for x in s if x > 270)/(kept[-1]-kept[0]):.2f}  >774: {sum(x for x in s if x > 774)/(kept[-1]-kept[0]):.2f}')
s = sorted(allint)
print(f'  pooled intervals n {len(s)}: median {st.median(s):.0f} p75 {s[3*len(s)//4]} p90 {s[9*len(s)//10]}')
rows = [r for r in csv.DictReader(open(p), delimiter='\t') if r['cls'] == 'fed']
for lo, hi in ((0, 270), (270, 774), (774, 2000), (2000, math.inf)):
    R = [r for r in rows if lo <= float(r['last_ret']) < hi and not math.isnan(float(r['route0']))]
    v = [float(r['route0']) for r in R]
    print(f'  fed departures with last laden arrival {lo}-{hi} frames ago: n {len(v):4}  route0 >=0.5 {sum(x >= 0.5 for x in v)/max(1,len(v)):.3f}  median {st.median(v) if v else float("nan"):.3f}')
