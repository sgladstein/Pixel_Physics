"""Where trail B is laid, from decision CSVs: every row with leg laden (CarryingFood 1 -> EmitB wire) and moved 1
lays B at (x2, y2) unless the arm is muted. Split by who (worker id%4==0 / forager), what (lunch: drive finite, i.e. a
packed-lunch carrier after act; trueladen: drive NaN), where along x (relative to nest_x; pile at nest_x+gap) and depth
(y2 > ybase+3 = underground, ybase = median y of at_nest rows on the surface band).
usage: layers.py CSV [CSV ...]"""
import sys, math, collections, statistics as st
tot = collections.Counter(); keys = set()
for path in sys.argv[1:]:
    f = open(path); hdr = f.readline().rstrip('\n').split(','); ix = {k: i for i, k in enumerate(hdr)}
    rows = []
    ys = []
    for line in f:
        p = line.split(',')
        if p[ix['at_nest']] == '1.0000' and abs(int(p[ix['x']]) - int(p[ix['nest_x']])) <= 2:
            ys.append(int(p[ix['y']]))
        if p[ix['leg']] == 'laden' and p[ix['moved']] == '1':
            rows.append((int(p[ix['id']]), p[ix['drive']] != 'NaN', int(p[ix['x2']]) - int(p[ix['nest_x']]), int(p[ix['y2']]), int(p[ix['gap']]), p[ix['seed']], p[ix['arm']]))
    ybase = min(ys)  # the shallowest head row beside the door: the surface walkers' row
    for aid, lunch, dx, y, gap, seed, arm in rows:
        keys.add((gap, seed, arm))
        who = 'worker' if aid % 4 == 0 else 'forager'
        what = 'lunch' if lunch else 'load'
        reg = ('west' if dx < -3 else 'door' if dx <= 3 else 'between' if dx < gap - 10 else 'pile' if dx <= gap + 10 else 'beyond')
        depth = 'under' if y > ybase + 3 else 'surf'
        tot[(who, what, reg, depth)] += 1
print(f'keys (gap,seed,arm): {len(keys)} {sorted(keys)[:3]}...')
T = sum(tot.values())
print(f'B-laying steps total {T}')
for who in ('forager', 'worker'):
    for what in ('load', 'lunch'):
        s = sum(v for k, v in tot.items() if k[0] == who and k[1] == what)
        if not s: continue
        cells = '  '.join(f"{reg} {tot[(who, what, reg, 'surf')]}/{tot[(who, what, reg, 'under')]}" for reg in ('west', 'door', 'between', 'pile', 'beyond'))
        print(f'  {who:7} {what:5} {s:7} ({s/T:.3f})  surface/underground: {cells}')
w_surf = sum(v for k, v in tot.items() if k[2] == 'west' and k[3] == 'surf')
e_surf = sum(v for k, v in tot.items() if k[2] == 'between' and k[3] == 'surf')
print(f'  SURFACE west of door {w_surf} ({w_surf/T:.3f}) vs surface door->pile {e_surf} ({e_surf/T:.3f});  west surface by lunch '
      f"{sum(v for k, v in tot.items() if k[2]=='west' and k[3]=='surf' and k[1]=='lunch')}")
