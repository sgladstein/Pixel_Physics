"""Pair two colony-bed arms seed by seed. usage: bedpair.py A.log B.log [labelA labelB]
Per run (keyed on gap, seed): taken from the pile (cells), food standing at the nest (mean J over samples 6000..24000),
born, starved, and the pellet-bite counter if printed. Prints key cardinality, totals, medians, sign pairs."""
import re, sys, math, statistics as st
def parse(path):
    # The per-run block (FOOD STORE, BIRTHS, FOOD BUDGET) is printed BEFORE that run's table row;
    # the 'founded ... born died (starved)' line after it. Pre-row lines go to `pend` until the row names the run.
    out = {}; key = None; pend = {}
    for line in open(path):
        m = re.match(r'^\s+(\d+)\s+(\d+)\s+(?:self|mute|hand)\s', line)
        if m:
            key = (int(m.group(1)), int(m.group(2))); out.setdefault(key, {}).update(pend); pend = {}; continue
        r = pend
        m = re.search(r'FOOD BUDGET \(cells.*taken from the pile (\d+)', line)
        if m: r['taken'] = int(m.group(1))
        if 'FOOD STORE (larder cells)' in line:
            v = [float(j) for f, j in re.findall(r'(\d+): nest ground.*?nest food (\d+) J', line) if int(f) >= 6000]
            v = [float(x) for x in re.findall(r'nest food (\d+) J', line)]
            fr = [int(x) for x in re.findall(r'\| (\d+): nest ground|-- (\d+): nest ground', line) for x in x if x]
            fr = [int(f) for f in re.findall(r'(\d+): nest ground', line)]
            r['nestfood'] = st.mean([j for f, j in zip(fr, v) if f >= 6000]) if fr else float('nan')
            b = [float(x) for x in re.findall(r'ant bodies (\d+) J', line)]
            r['bodies'] = st.mean([j for f, j in zip(fr, b) if f >= 6000]) if b else float('nan')
        m = re.search(r'born\s+(\d+) died\s+(\d+) \(starved\s+(\d+)\)', line)
        if m and 'founded' in line and key: r = out[key]; r['born'] = int(m.group(1)); r['starved'] = int(m.group(3))
        m = re.search(r'mouthfuls refused for a pellet held (\d+)', line)
        if m: r['refused'] = int(m.group(1))
    return out
def sign(a, b):
    hi = sum(y > x for x, y in zip(a, b)); lo = sum(y < x for x, y in zip(a, b)); n, k = hi + lo, min(hi, lo)
    p = min(1, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1
    return f"{hi}/{lo} p{p:.3f}"
A, B = parse(sys.argv[1]), parse(sys.argv[2])
la, lb = (sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else ('A', 'B')
K = sorted(set(A) & set(B))
print(f"keyed: {la} {len(A)} runs, {lb} {len(B)} runs, paired {len(K)}; gaps {sorted(set(k[0] for k in K))}")
for k, lab in (('taken', 'taken from the pile, cells'), ('nestfood', 'food standing at the nest, J'), ('bodies', "in ants' bodies, J"),
               ('born', 'born'), ('starved', 'starved'), ('refused', 'mouthfuls refused for a pellet')):
    ks = [x for x in K if k in A[x] and k in B[x]]
    if not ks: continue
    a = [A[x][k] for x in ks]; b = [B[x][k] for x in ks]
    print(f"  {lab:32} total {sum(a):>10,.0f} -> {sum(b):>10,.0f}   median {st.median(a):>9,.0f} -> {st.median(b):>9,.0f}   B higher/lower {sign(a, b)}  (n {len(ks)})")
