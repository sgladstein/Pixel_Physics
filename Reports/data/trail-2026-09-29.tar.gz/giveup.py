"""Trace every west-going and east-going committed forager excursion (fed, hungry, lunch) through the scout's give-up.
usage: giveup.py dep-<arm>.tsv CSVDIR TAG [example]
For each excursion (from departures.py): the first row with scout_home 1 (the scout has given up and is pulled home),
the frames from departure to it, from it to the return, and, over the stepped B-reading rows AFTER it, the share on a
route (chosen_route >= 0.5) and the share whose picked heading points AWAY from home (chosen_cos < 0; chosen_cos is the
home cosine of the heading picked, negative outward). `example` prints one fed west excursion row by row (every 5th row).
Per-seed medians are paired by the caller."""
import sys, csv, gzip, os, math, collections, statistics as st
dep_path, csvdir, tag = sys.argv[1], sys.argv[2], sys.argv[3]
example = len(sys.argv) > 4
deps = [r for r in csv.DictReader(open(dep_path), delimiter='\t')
        if r['cls'] in ('fed', 'hungry', 'lunch') and r['dir30'] in ('E', 'W') and (float(r['max_e']) >= 10 or float(r['min_w']) <= -10)]
by_seed = collections.defaultdict(list)
for r in deps: by_seed[(r['gap'], r['seed'], r['arm'])].append(r)
out = []
shown = False
for (gap, seed, arm), D in sorted(by_seed.items(), key=lambda kv: int(kv[0][1])):
    base = f'{csvdir}/trailfollow-decisions-seed{seed}-gap{gap}-{arm}-{tag}.csv'
    fh = gzip.open(base + '.gz', 'rt') if os.path.exists(base + '.gz') else open(base)
    hdr = fh.readline().rstrip('\n').split(','); ix = {k: i for i, k in enumerate(hdr)}
    want = collections.defaultdict(list)
    for r in D: want[int(r['id'])].append(r)
    rows = collections.defaultdict(list)
    for line in fh:
        p = line.split(',')
        i = int(p[ix['id']])
        if i in want: rows[i].append(p)
    for i, R in want.items():
        tr = rows[i]
        frames = [int(p[ix['frame']]) for p in tr]
        for r in R:
            f0 = int(r['frame']); k = frames.index(f0)
            exc = [tr[k]]
            for p in tr[k + 1:]:
                if float(p[ix['at_nest']]) >= 0.5: break
                exc.append(p)
            gi = next((j for j, p in enumerate(exc) if p[ix['scout_home']] == '1'), None)
            def rb(p):
                return p[ix['outcome']] == 'stepped' and p[ix['chosen_route']] != 'NaN' and (
                    (p[ix['leg']] == 'empty' and float(p[ix['fill']]) == 0.0) or (p[ix['leg']] == 'laden' and p[ix['drive']] != 'NaN'))
            after = [p for p in exc[gi:] if rb(p)] if gi is not None else []
            onr = sum(float(p[ix['chosen_route']]) >= 0.5 for p in after)
            outw = sum(float(p[ix['chosen_cos']]) < 0 for p in after if p[ix['chosen_cos']] != 'NaN')
            t_give = int(exc[gi][ix['frame']]) - f0 if gi is not None else math.nan
            t_after = (int(exc[-1][ix['frame']]) - int(exc[gi][ix['frame']])) if gi is not None else math.nan
            out.append(dict(seed=seed, arm=arm, cls=r['cls'], dir=r['dir30'], outcome=r['outcome'], gave_up=gi is not None,
                            t_give=t_give, t_after=t_after, n_after=len(after), on_after=onr, out_after=outw))
            if example and not shown and r['cls'] == 'fed' and r['dir30'] == 'W' and gi is not None and len(after) > 30:
                shown = True
                print(f'EXAMPLE seed {seed} arm {arm} ant {i}, fed, left at frame {f0}; every 5th row, ! marks scout_home')
                print('  frame   dx   y  leg   outcome        route   chosen_cos scout_w patience drive  energy_j')
                for j, p in enumerate(exc):
                    if j % 5 and j != gi: continue
                    print(f"  {p[ix['frame']]:>6} {int(p[ix['x']]) - int(p[ix['nest_x']]):+4d} {p[ix['y']]:>3} {p[ix['leg']]:5} {p[ix['outcome']]:15} {p[ix['chosen_route']]:>7} {p[ix['chosen_cos']]:>8} "
                          f"{p[ix['scout_w']]:>7} {p[ix['scout_patience']]:>7} {p[ix['drive']]:>6} {p[ix['energy_j']]:>8} {'!' if p[ix['scout_home']] == '1' else ''}")
                    if j > 400: print('  ...'); break
keys = sorted(set((o['seed'], o['arm']) for o in out))
print(f'{dep_path}: {len(out)} excursions, keys {len(keys)}')
for d in ('W', 'E'):
    for cls in ('fed', 'hungry', 'lunch', 'all'):
        O = [o for o in out if o['dir'] == d and (cls == 'all' or o['cls'] == cls)]
        G = [o for o in O if o['gave_up']]
        if not O: continue
        na = sum(o['n_after'] for o in G)
        print(f"  {d} {cls:6} n {len(O):4}  gave up {len(G):4} ({len(G)/len(O):.2f})  frames to give up median {st.median([o['t_give'] for o in G]) if G else math.nan:6.0f}"
              f"  give-up -> back median {st.median([o['t_after'] for o in G]) if G else math.nan:6.0f}  after give-up: on route {sum(o['on_after'] for o in G)/max(1,na):.3f}  heading outward {sum(o['out_after'] for o in G)/max(1,na):.3f} (rows {na})")
with open(dep_path.replace('.tsv', '') + '.giveup.tsv', 'w') as f:
    f.write('\t'.join(out[0].keys()) + '\n')
    for o in out: f.write('\t'.join(str(v) for v in o.values()) + '\n')
