"""Summarise departures TSVs from departures.py, per arm and class, and pair arms within seed.
usage: summarize.py dep-A.tsv [dep-B.tsv ...]
COMMITTED = the excursion got >= 10 cells from nest_x (max_e >= 10 or min_w <= -10)."""
import sys, csv, math, statistics as st, collections

def load(p):
    return [r for r in csv.DictReader(open(p), delimiter='\t')]

def f(x):
    return float(x)

def sign(a, b):
    hi = sum(y > x for x, y in zip(a, b)); lo = sum(y < x for x, y in zip(a, b)); n, k = hi + lo, min(hi, lo)
    p = min(1, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1
    return f"{hi}/{lo} p{p:.3f}"

def block(rows, label):
    n = len(rows)
    if not n:
        print(f'  {label:26} n 0'); return {}
    com = [r for r in rows if f(r['max_e']) >= 10 or f(r['min_w']) <= -10]
    r0 = [f(r['route0']) for r in rows if not math.isnan(f(r['route0']))]
    ab = [f(r['alongb0']) for r in rows]
    n200 = sum(int(r['n200']) for r in com); on50 = sum(int(r['on50']) for r in com); on10 = sum(int(r['on10']) for r in com); anyr = sum(int(r['any']) for r in com)
    d30 = collections.Counter(r['dir30'] for r in com); f15 = collections.Counter(r['first15'] for r in com)
    oc = collections.Counter(r['outcome'] for r in com)
    tp = sorted(int(r['t_out']) for r in com if r['outcome'] == 'pile')
    tr = sorted(int(r['t_out']) for r in com if r['outcome'] == 'returned')
    lr = sorted(f(r['last_ret']) for r in rows)
    med = lambda v: (st.median(v) if v else float('nan'))
    print(f'  {label:26} departures {n:5}  committed {len(com):5}')
    print(f'      B at departure (route0, n {len(r0)}): >0 {sum(x > 0 for x in r0)/max(1,len(r0)):.3f}  >=0.1 {sum(x >= 0.1 for x in r0)/max(1,len(r0)):.3f}  >=0.5 {sum(x >= 0.5 for x in r0)/max(1,len(r0)):.3f}  median {med(r0):.3f}'
          f'   along_b !=0 {sum(x != 0 for x in ab)/n:.3f}')
    print(f'      next<=200 stepped rows (committed): {n200}  on route >=0.5 {on50/max(1,n200):.3f}  >=0.1 {on10/max(1,n200):.3f}  >0 {anyr/max(1,n200):.3f}')
    e, w = d30['E'], d30['W']
    print(f'      dir30 (committed): E {e}  W {w}  0 {d30["0"]}  never30 {d30["-"]}   E share of E+W {e/max(1,e+w):.3f}'
          f'   first15: E {f15["E"]} W {f15["W"]} none {f15["-"]}  E share {f15["E"]/max(1,f15["E"]+f15["W"]):.3f}')
    print(f'      outcome (committed): pile {oc["pile"]} ({oc["pile"]/max(1,len(com)):.3f})  returned {oc["returned"]}  end {oc["end"]}'
          f'   frames to pile median {med(tp):.0f} (p25 {tp[len(tp)//4] if tp else float("nan")}, p75 {tp[3*len(tp)//4] if tp else float("nan")})   to return median {med(tr):.0f}')
    print(f'      frames since last laden arrival at departure: median {med(lr):.0f}  share <=270 {sum(x <= 270 for x in lr)/n:.3f}  share inf {sum(math.isinf(x) for x in lr)/n:.3f}')
    return dict(n=n, com=len(com), E=e, W=w, pile=oc['pile'], on50=on50, n200=n200)

arms = {}
for p in sys.argv[1:]:
    rows = load(p)
    keys = collections.Counter((r['gap'], r['seed'], r['arm']) for r in rows)
    arm = rows[0]['arm']
    print(f'== {p}: arm {arm}, {len(rows)} departures, key (gap,seed,arm) cardinality {len(keys)}: {sorted(set(k[1] for k in keys), key=int)}')
    for cls in ('fed', 'hungry', 'lunch', 'worker', 'laden', 'spoil'):
        block([r for r in rows if r['cls'] == cls], cls)
    arms[arm] = rows

# paired within seed, fed and hungry: E share (dir30), pile share, on-route share
names = list(arms)
if len(names) >= 2:
    print('== paired within (gap, seed), committed departures')
    for cls in ('fed', 'hungry', 'lunch'):
        for q in ('Eshare', 'pile', 'on50'):
            per = {}
            for a in names:
                d = collections.defaultdict(lambda: [0, 0, 0, 0, 0, 0])
                for r in arms[a]:
                    if r['cls'] != cls or not (f(r['max_e']) >= 10 or f(r['min_w']) <= -10): continue
                    k = (r['gap'], r['seed']); v = d[k]
                    v[0] += r['dir30'] == 'E'; v[1] += r['dir30'] == 'W'; v[2] += r['outcome'] == 'pile'; v[3] += 1
                    v[4] += int(r['on50']); v[5] += int(r['n200'])
                per[a] = {k: (v[0] / max(1, v[0] + v[1]) if q == 'Eshare' else v[2] / max(1, v[3]) if q == 'pile' else v[4] / max(1, v[5])) for k, v in d.items() if v[3] >= 3}
            for a, b in [(names[i], names[j]) for i in range(len(names)) for j in range(i + 1, len(names))]:
                K = sorted(set(per[a]) & set(per[b]))
                va = [per[a][k] for k in K]; vb = [per[b][k] for k in K]
                if K:
                    print(f'  {cls:7} {q:6} {a}->{b}: n {len(K)} seeds  median {st.median(va):.3f} -> {st.median(vb):.3f}  {b} higher/lower {sign(va, vb)}   per seed ' +
                          ' '.join(f'{x:.2f}/{y:.2f}' for x, y in zip(va, vb)))
