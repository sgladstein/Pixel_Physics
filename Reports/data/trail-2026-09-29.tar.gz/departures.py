"""Departures from the nest, ant by ant, from trailfollow decision CSVs.

usage: departures.py OUT.tsv CSV [CSV ...]

A DEPARTURE is a decision row of one ant whose previous row (same id) read at_nest 1
and this one reads at_nest 0. Class, at that row:
  worker  id % 4 == 0 (the nest-worker caste, Storeroom::SHIPPED caste=4) -- excluded from forager classes
  fed     leg empty, energy_j >= 200
  hungry  leg empty, energy_j < 200
  lunch   leg laden and drive not NaN (a packed-lunch carrier: CarryingFood 1, but the drive is felt)
  laden   leg laden, drive NaN (a true load; not a forager departure)
  spoil   leg spoil
The EXCURSION runs from the departure row until the next row reading at_nest 1 (return) or the ant's last row.
Per departure:
  route0     chosen_route (trail presence of the heading picked; B for an empty/lunch chooser) of the first
             STEPPED row in the first 3 rows of the excursion, NaN if none stepped
  alongb0    along_b at the departure row (sensed B forward difference; not used by the chooser)
  n200/on50/on10/any  over the next <=200 rows of the excursion while the class holds (leg unchanged):
             stepped rows with a finite chosen_route; of those >=0.5, >=0.1, >0
  dir30      E/W/- : sign of (x - x_dep) once the summed |dx| of the excursion reaches 30 cells; '-' if it never does
  first15    E/W/- : which of x >= nest_x+15 / x <= nest_x-15 the excursion reaches first
  outcome    pile   (x >= nest_x + gap - 10 at any row of the excursion), returned, end
  t_out      frames from departure to that outcome
  last_ret   frames since the most recent LADEN ARRIVAL at this ant's nest (any ant: at_nest 0->1, leg laden,
             drive NaN, trip_load 1) -- inf if none yet
Also writes OUT.tsv.arrivals (seed arm frame id) and OUT.tsv.layers (B deposits: rows leg laden & moved 1, by
source lunch/trueladen and by region of x2 relative to nest_x and the pile).
"""
import sys, csv, math, collections

out_path = sys.argv[1]
paths = sys.argv[2:]
dep_rows = []
arr_rows = []
lay = collections.Counter()
for path in paths:
    f = open(path)
    hdr = f.readline().rstrip('\n').split(',')
    ix = {k: i for i, k in enumerate(hdr)}
    need = ['seed', 'gap', 'arm', 'frame', 'id', 'leg', 'x', 'y', 'x2', 'at_nest', 'along_b', 'nest_x', 'outcome', 'moved',
            'chosen_route', 'energy_j', 'drive', 'trip_load', 'scout_home', 'fill']
    I = {k: ix[k] for k in need}
    by_id = collections.defaultdict(list)
    seed = gap = arm = None
    for line in f:
        p = line.split(',')
        r = (int(p[I['frame']]), int(p[I['id']]), p[I['leg']], int(p[I['x']]), int(p[I['x2']]), float(p[I['at_nest']]),
             float(p[I['along_b']]), int(p[I['nest_x']]), p[I['outcome']], p[I['moved']] == '1', float(p[I['chosen_route']]),
             float(p[I['energy_j']]), float(p[I['drive']]), p[I['trip_load']] == '1', p[I['scout_home']] == '1', int(p[I['y']]), float(p[I['fill']]))
        by_id[r[1]].append(r)
        if seed is None:
            seed, gap, arm = int(p[I['seed']]), int(p[I['gap']]), p[I['arm']]
    f.close()
    FR, ID, LEG, X, X2, AN, AB, NX, OUT, MV, CR, EJ, DR, TL, SH, Y, FL = range(17)

    def reads_b(r):
        # the chooser read trail B on this row: empty after act (leg empty, fill 0), or a lunch carrier after act
        # (leg laden, drive finite). A row where the ant loaded food in `act` reads trail A and is excluded.
        return (r[LEG] == 'empty' and r[FL] == 0.0) or (r[LEG] == 'laden' and not math.isnan(r[DR]))
    # laden arrivals, all ants
    arrivals = []
    for aid, rows in by_id.items():
        for a, b in zip(rows, rows[1:]):
            if a[AN] < 0.5 and b[AN] >= 0.5 and b[LEG] == 'laden' and math.isnan(b[DR]) and b[TL]:
                arrivals.append(b[FR])
                arr_rows.append((seed, gap, arm, b[FR], aid))
        # B deposits: every moved row of a leg-laden ant lays B (CarryingFood 1 -> EmitB); mute zeroes the wire
        for r in rows:
            if r[LEG] == 'laden' and r[MV]:
                src = 'lunch' if not math.isnan(r[DR]) else 'trueladen'
                dx = r[X2] - r[NX]
                pile = gap
                reg = ('west' if dx < -3 else 'door' if dx <= 3 else 'between' if dx < pile - 10 else 'pile' if dx <= pile + 10 else 'beyond')
                lay[(seed, gap, arm, src, reg)] += 1
    arrivals.sort()

    def last_ret(fr):
        # most recent arrival strictly before fr
        lo, hi = 0, len(arrivals)
        while lo < hi:
            m = (lo + hi) // 2
            if arrivals[m] < fr: lo = m + 1
            else: hi = m
        return fr - arrivals[lo - 1] if lo else math.inf

    for aid, rows in by_id.items():
        for i in range(1, len(rows)):
            a, b = rows[i - 1], rows[i]
            if not (a[AN] >= 0.5 and b[AN] < 0.5):
                continue
            if aid % 4 == 0: cls = 'worker'
            elif b[LEG] == 'empty': cls = 'fed' if b[EJ] >= 200 else 'hungry'
            elif b[LEG] == 'laden': cls = 'lunch' if not math.isnan(b[DR]) else 'laden'
            else: cls = 'spoil'
            nx = b[NX]
            # excursion rows
            j = i
            exc = []
            while j < len(rows) and (j == i or rows[j][AN] < 0.5):
                exc.append(rows[j]); j += 1
            returned = j < len(rows)
            route0 = math.nan
            for r in exc[:3]:
                if r[OUT] == 'stepped' and not math.isnan(r[CR]) and reads_b(r):
                    route0 = r[CR]; break
            n200 = on50 = on10 = anyr = 0
            for r in exc[:200]:
                if r[LEG] == 'laden' and math.isnan(r[DR]): break   # found a load: no longer an outbound forager
                if r[OUT] == 'stepped' and not math.isnan(r[CR]) and reads_b(r):
                    n200 += 1; on50 += r[CR] >= 0.5; on10 += r[CR] >= 0.1; anyr += r[CR] > 0
            moved = 0; dir30 = '-'; x0 = b[X]
            for r in exc:
                moved += abs(r[X2] - r[X])
                if moved >= 30:
                    d = r[X2] - x0
                    dir30 = 'E' if d > 0 else 'W' if d < 0 else '0'
                    break
            first15 = '-'
            for r in exc:
                if r[X2] >= nx + 15: first15 = 'E'; break
                if r[X2] <= nx - 15: first15 = 'W'; break
            outcome, t_out = 'end', exc[-1][FR] - b[FR]
            for r in exc:
                if r[X2] >= nx + gap - 10:
                    outcome, t_out = 'pile', r[FR] - b[FR]; break
            else:
                if returned:
                    outcome, t_out = 'returned', rows[j][FR] - b[FR]
            maxe = max(r[X2] for r in exc) - nx
            minw = min(r[X2] for r in exc) - nx
            dep_rows.append((seed, gap, arm, aid, cls, b[FR], b[X] - nx, b[Y], b[DR], b[EJ], b[AB], route0, n200, on50, on10, anyr,
                             dir30, first15, outcome, t_out, len(exc), maxe, minw, last_ret(b[FR])))

with open(out_path, 'w') as o:
    o.write('seed\tgap\tarm\tid\tcls\tframe\tdx_dep\ty_dep\tdrive\tenergy_j\talongb0\troute0\tn200\ton50\ton10\tany\tdir30\tfirst15\toutcome\tt_out\texc_rows\tmax_e\tmin_w\tlast_ret\n')
    for d in dep_rows:
        o.write('\t'.join(str(v) for v in d) + '\n')
with open(out_path + '.arrivals', 'w') as o:
    o.write('seed\tgap\tarm\tframe\tid\n')
    for a in arr_rows: o.write('\t'.join(map(str, a)) + '\n')
with open(out_path + '.layers', 'w') as o:
    o.write('seed\tgap\tarm\tsrc\tregion\tdeposits\n')
    for k, v in sorted(lay.items()): o.write('\t'.join(map(str, k)) + f'\t{v}\n')
keys = sorted(set((d[0], d[1], d[2]) for d in dep_rows))
print(f'{out_path}: {len(dep_rows)} departures over {len(keys)} (seed,gap,arm) keys from {len(paths)} files; '
      f'{len(arr_rows)} laden arrivals')
