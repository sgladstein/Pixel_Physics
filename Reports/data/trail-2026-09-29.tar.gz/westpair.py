"""Paired within seed: how long outbound foragers (fed, hungry, lunch; committed departures) spend on excursions that
went WEST (dir30 W) vs EAST, arm A vs arm B. usage: westpair.py dep-A.tsv dep-B.tsv"""
import sys, csv, collections, statistics as st, math
def sign(a, b):
    hi = sum(y > x for x, y in zip(a, b)); lo = sum(y < x for x, y in zip(a, b)); n, k = hi + lo, min(hi, lo)
    p = min(1, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1
    return f"{hi}/{lo} p{p:.3f}"
def per_seed(path):
    d = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in csv.DictReader(open(path), delimiter='\t'):
        if r['cls'] not in ('fed', 'hungry', 'lunch'): continue
        if not (float(r['max_e']) >= 10 or float(r['min_w']) <= -10): continue
        d[(r['gap'], r['seed'])][r['dir30']].append(int(r['exc_rows']) * 6)  # rows are 6 frames apart
    return d
A, B = per_seed(sys.argv[1]), per_seed(sys.argv[2])
K = sorted(set(A) & set(B), key=lambda k: int(k[1]))
print(f'keys A {len(A)} B {len(B)} paired {len(K)}')
for q, fn in (('W excursion frames, total', lambda v: sum(v['W'])), ('W excursion frames, median', lambda v: st.median(v['W']) if v['W'] else 0),
              ('E excursion frames, median', lambda v: st.median(v['E']) if v['E'] else 0), ('W excursions, count', lambda v: len(v['W'])),
              ('E excursions, count', lambda v: len(v['E'])), ('W share of E+W frames', lambda v: sum(v['W']) / max(1, sum(v['W']) + sum(v['E'])))):
    a = [fn(A[k]) for k in K]; b = [fn(B[k]) for k in K]
    print(f'  {q:28} total/median {sum(a):>9.1f} -> {sum(b):>9.1f}   median {st.median(a):8.2f} -> {st.median(b):8.2f}   B higher/lower {sign(a, b)}')
