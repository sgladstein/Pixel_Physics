"""Trail B as the outbound forager meets it, by x band: over stepped rows where the chooser read B (leg empty & fill 0,
or a lunch carrier: leg laden & drive finite), forager ids only (id%4 != 0), surface only (y2 <= ybase+3),
the share whose picked heading is on a route (chosen_route >= 0.5), and the rows' count, per 10-column band of
x - nest_x. Also, fed empty rows only (energy_j >= 200).
usage: routemap.py CSV [CSV ...]"""
import sys, math, collections
bands = list(range(-60, 110, 10))
cnt = collections.Counter(); on = collections.Counter(); keys = set()
for path in sys.argv[1:]:
    f = open(path); hdr = f.readline().rstrip('\n').split(','); ix = {k: i for i, k in enumerate(hdr)}
    rows = []; ys = []
    for line in f:
        p = line.split(',')
        if p[ix['at_nest']] == '1.0000' and abs(int(p[ix['x']]) - int(p[ix['nest_x']])) <= 2:
            ys.append(int(p[ix['y']]))
        if p[ix['outcome']] != 'stepped' or int(p[ix['id']]) % 4 == 0 or p[ix['chosen_route']] == 'NaN':
            continue
        leg = p[ix['leg']]; fill = float(p[ix['fill']]); dr = p[ix['drive']]
        if leg == 'empty' and fill == 0.0: cls = 'fed' if float(p[ix['energy_j']]) >= 200 else 'hungry'
        elif leg == 'laden' and dr != 'NaN': cls = 'lunch'
        else: continue
        rows.append((cls, int(p[ix['x']]) - int(p[ix['nest_x']]), int(p[ix['y2']]), float(p[ix['chosen_route']])))
        keys.add((p[ix['gap']], p[ix['seed']], p[ix['arm']]))
    ybase = min(ys)
    for cls, dx, y, cr in rows:
        if y > ybase + 3: continue
        b = max(-60, min(100, (dx // 10) * 10))
        for c in (cls, 'all'):
            cnt[(c, b)] += 1; on[(c, b)] += cr >= 0.5
print(f'keys {len(keys)}; band = 10 columns from x - nest_x (clamped to [-60,100]); cell = on-route share (rows)')
for c in ('all', 'fed', 'hungry', 'lunch'):
    print(f'  {c:6} ' + ' '.join(f'{b:+d}:{on[(c, b)]/cnt[(c, b)]:.2f}({cnt[(c, b)]})' for b in bands if cnt[(c, b)]))
