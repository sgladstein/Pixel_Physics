# trailq findings (2026-09-29, tf-518 = trailfollow @ main 2274e347; source identical at fb1ee2ac)
Bed env: RAYON_NUM_THREADS=1 COLONY_SPACING=2 STACK_DEPTH=4 BUD_SITE=nest; frames=24000 ants=20 near=10 food=400 refill=400
Runs: run1.sh ARM GAP SEED0 [dtag]; logs in logs/. Reader: bedpair2.py (= py/bedpair.py with row regex widened to self|mute|hand).

## 0. Determinism
self gap90 seeds1-8 rerun WITH decisioncsv vs b518u-90.log seeds 1-8: every column identical (taken 2,125=2,125; born 70=70; starved 24=24), 0/0 sign.
So decisioncsv does not perturb the run, and b518u-*.log is the self arm on this binary.

## 1. Does the trail help? self (b518u) vs mute (EmitB zeroed; A still laid), 24 seeds each gap, paired within (gap,seed)
cmd: python3 bedpair2.py /home/user/runs/b518u-90.log mute-90.log self mute  (and -140)
gap 90  (n 24): taken 6,062 -> 7,512 (median 259 -> 319), mute higher 21/3 p<0.001
               nest food J 297,943 -> 329,413, 16/8 p0.152; bodies J 149,721 -> 193,196, 19/5 p0.007
               born 188 -> 282, 17/6 p0.035; starved 57 -> 29, mute lower 15/5 (5 higher) p0.041
gap 140 (n 24): taken 4,287 -> 5,412 (median 182 -> 229), 17/7 p0.064
               nest food J 194,687 -> 239,007, 15/9 p0.307; bodies J 95,741 -> 131,442, 20/4 p0.002
               born 63 -> 107, 16/6 p0.052; starved 127 -> 54, mute lower 15/6 p0.078
=> On today's main the food trail does not help; silencing it is better on every outcome, at both gaps.

## 2. What a leaving forager finds (gap 90, seeds 1-8, decisioncsv; self vs mute vs hand, same seeds)
Scripts: departures.py (per-departure TSV dep-90-<arm>.tsv), summarize.py -> sum-90.txt, routemap.py -> routemap-90.txt,
layers.py, westpair.py, part3.py -> part3-90.txt. Key cardinality 8 (gap,seed,arm) per arm, checked in every script.
Departure = at_nest 1 -> 0 on consecutive rows of one ant. Classes: worker id%4==0; fed = leg empty & energy_j>=200;
hungry = leg empty & <200; lunch = leg laden & drive finite. "Committed" = got >=10 cells from nest_x.
Route readings only on rows where the chooser read B (leg empty & fill 0 after act, or lunch). Without that filter,
mute read "on route" at 43% of fed departures: ants that load food in `act` on the first step read trail A.
NEGATIVE CONTROL (mute, B never laid): fed on-route at departure 0.000 (n 533), next-200 0.000 (n 12,403). Clean.
POSITIVE CONTROL (hand): fed next-200 on-route 0.868 vs self 0.703; per seed hand > self 7/1, hand > mute 8/0.

(a) B at departure, fed (route0 = chosen_route of first stepped B-reading row within 3 rows):
    self >=0.5 in 0.987 (n 450), median 0.913; hungry 0.714 (n 371); lunch 0.996 (n 1161). hand fed 0.989. mute 0.000.
(b) next <=200 B-reading stepped rows, committed departures, on route >=0.5:
    self fed 0.703 (n 12,411 rows), hungry 0.528, lunch 0.760; hand fed 0.868; mute 0.000.
(c) direction, committed fed departures, sign of x displacement after 30 cells of |dx|:
    self E 106 / W 53 (E share 0.667); mute E 119 / W 50 (0.704); hand E 107 / W 40 (0.728).
    Paired per seed E share: self->mute 4/4 p1.0; self->hand 6/2 p0.29.  => the trail does not change which way a fed ant leaves.
    hungry: self 0.478, mute 0.468, hand 0.569.  lunch: self 0.614, mute 0.554, hand 0.589.
(d) committed fed departures reaching the pile (x >= nest_x+80): self 0.497 (92/185), mute 0.528 (102/193), hand 0.599 (97/162);
    paired: self->mute mute higher 6/2 p0.29; self->hand hand higher 8/0 p0.008. Frames to pile median: self 750, mute 720, hand 750.
    West-going committed departures NEVER reach the pile (self fed 0/53, mute 0/50, hand 0/40); they reach min_w -44 = the west wall (x=4; nest_x=48 in all 8 seeds).

## 2b. Why the trail cannot tell east from west (self gap 90, 8 seeds)
B-laying steps (moved rows with CarryingFood 1: EmitB is wired from CarryingFood, and a packed-lunch carrier has CarryingFood 1
so it lays B on its OUTBOUND scout): 240,740. Surface west of the door (x < nest_x-3, y <= surface+3) 33,555 (13.9%)
vs surface door->pile 79,912 (33.2%). Of the west-surface steps: lunch carriers 15,536 (46%), laden foragers 11,839, laden workers 6,180.
(layers.py; hand arm: 40,501 west vs 86,093 path.)
On-route share (picked heading presence >=0.5) of outbound B-readers by 10-column band (routemap.py), self:
    west bands -50..-20: 0.52 0.51 0.43 0.42;  door -10/0: 0.69 0.88;  path +10..+80: 0.74 0.72 0.75 0.75 0.73 0.75 0.78 0.81.
    fed only: west 0.51 0.63 0.56 0.50; path 0.77-0.86. hand: west 0.44-0.64, path 0.95-0.99. mute: 0.00 everywhere.
Time outbound B-readers spend on the surface: self west (-50..-20) 43,919 rows vs east (+10..+80) 31,179 (58% west);
    mute 32,262 vs 36,245 (47% west); hand 45,181 vs 33,981 (57% west).
West-going excursion length (committed fed+hungry+lunch, per-seed median, westpair.py): self 1,806 frames vs mute 1,095, longer with
    the trail in 8/8 seeds (p0.008); hand 1,809 (5/3 vs self). East-going: self 1,746 vs mute 1,695 (3/5). West share of
    excursion time: self 0.40 vs mute 0.30 (mute lower 7/8 p0.07).
Code (read): creature.rs chooser score: away term -AWAY_GAIN*route(d)*cos(home) has no patience; the scout's give-up pull home is
    scout_w*(1-route(d))*cos -- scaled OFF on a route. So on any B, including a west B, a leaving ant is pushed outward with no give-up.

## 3. How long B lasts between returns, and what the door reads (self gap 90, 8 seeds; part3.py)
Laden arrivals (at_nest 0->1, leg laden, drive NaN, trip_load 1; same ant within 200 frames deduped): 253 intervals,
    median 432 frames, p75 918, p90 1,710; per seed 90-95% of the time lies in gaps >270 (B's decay half-life,
    12*ln2/-ln(0.97) = 273 frames) and 61-84% in gaps >774 (decay alone takes one step's deposit 7,311 raw below TRAIL_HALF 1,024).
    (harness `trips` for the same seeds: 494, my laden arrivals 294 -- trips close on any return after reaching the food, loaded or not.)
Yet fed departures read B >=0.5 at the door whatever the age of the last laden return:
    0-270 frames: 0.992 (n 124); 270-774: 0.993 (147); 774-2000: 0.993 (135); >2000: 1.000 (41).
    => the door's B is held up by food handled AT the door (laden ants putting down, lunch pickups), not by trips. It is saturated, so it
    carries no bearing and no news of recent success.

## 2c. The door gives no bearing; the west B traps the wrong-way ant (trace, every excursion; giveup.py)
B at the first step off the door, committed fed departures, by where they went (gap 90 self): east-goers median 0.877 (>=0.5 in 100%, n 89),
    west-goers 0.893 (98%, n 42). Same in hand (0.918 / 0.913) and at gap 140 self (0.839 / 0.768). East-goers step off column +3, west-goers -2/-3:
    the side is set by which edge of the five-column door the ant steps off, and the trail reads the same on both.
Scout give-up (scout_home 1) on WEST-going committed forager excursions, gap 90: self 230/274 give up (0.84), median 603 frames out;
    after giving up: back home median 1,392 frames (mute 504, hand 1,326); on route 0.643 of B-reading steps; picked heading points AWAY
    from home on 0.432 (mute 0.106). Per seed: give-up -> back self > mute 8/8 (1347/495 1746/516 1282/475 2118/492 1461/543 1368/507 1170/546 756/456, p0.008);
    outward share after give-up self > mute 8/8 (0.38-0.48 vs 0.03-0.19, p0.008).
Gap 140 replication (seeds 1-8, decisioncsv; reruns bit-identical to b518u-140/mute-140 on those seeds): west excursion per-seed median
    1,569 vs 1,127 frames, longer with trail 8/8 p0.008; outward share after give-up 0.31-0.48 vs 0.04-0.29, 8/8 p0.008; give-up -> back 7/1 p0.07.
    fed E share self 0.529 (27/24) vs mute 0.680 (87/41), per seed 5/3 n.s.; fed reaching pile 0.323 vs 0.466, mute higher 7/1 p0.07.
    West bands on-route (all B-readers) 0.25-0.46 vs path 0.50-0.60.
One ant (seed 1, ant 3, fed 581 J, drive 1.0, left frame 18438): walks from door -4 to the west wall -44 in ~400 frames on B 0.35-0.71,
    climbs the wall, patience 0.0985 -> gives up at 19086, walks home to -14, meets B 0.87 there and turns outward again (chosen_cos -0.99
    at -15..-25, route 0.53-0.61) while still flagged scout_home.

## antloop funnel, gap 90 seeds 1-8 (antloop.py, antloop-90-<arm>.txt)
full loops self 429 / mute 488 / hand 480; reached the food 162/197 (82.2%) / 181/214 (84.6%) / 177/209 (84.7%);
starved 24/197 (12.2%) / 6/214 (2.8%) / 5/209 (2.4%).

## 1b. Laying-cost confound on result 1 (the only non-steering difference between self and mute)
trail laying burn, 24 runs: gap 90 self 12,371 J vs mute 5,689 J (diff 6,682 J); gap 140 9,897 vs 4,509 (diff 5,388 J).
Bodies-J difference was +43,475 J (gap 90) and +35,701 J (gap 140): laying cost is at most ~15% of it, and cannot explain
cells taken from the pile (21/3 at gap 90). The harm is steering, per 2b/2c.
