#!/bin/bash
# one bed run: run1.sh ARM GAP SEED0 [dtag]  -> logs/<arm>-<gap>-s<seed0>.log
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
arm=$1; gap=$2; s0=$3; tag=$4
extra=""
if [ -n "$tag" ]; then extra="decisioncsv dtag=$tag decisiondir=/home/user/runs/trailq/csv"; fi
/home/user/runs/tf-518 mode=gap gate=shipped frames=24000 ants=20 near=10 food=400 refill=400 arms=$arm gaps=$gap seeds=8 seed0=$s0 $extra > /home/user/runs/trailq/logs/$arm-$gap-s$s0.log 2> /home/user/runs/trailq/logs/$arm-$gap-s$s0.err
echo "exit $? $arm $gap $s0 $(date +%T)" >> /home/user/runs/trailq/logs/done.txt
