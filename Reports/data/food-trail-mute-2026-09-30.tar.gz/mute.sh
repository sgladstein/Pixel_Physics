#!/bin/bash
# Step F: the heritable mute (World::mute_emit_b). Frozen binary tf-s1d.
# Resumable: a job whose log already holds its final summary is skipped.
#  id-*    self arms, identity against tf-s1e/tf-s1c (the game is untouched)
#  mute-*  the mute arm under the default (lay); muteoff-* under FOOD_TRAIL=off.
#          With the heritable switch the two must be identical (ft label aside).
cd /home/user/runs/s1d
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
job() { local name=$1 ft=$2 A=$3 gap=$4 pile=$5 s0=$6 ants=$7 extra=$8
  local f=logs/$name.log
  if grep -q 'measuring a dead colony, not a deaf one' $f 2>/dev/null; then echo "$name skip"; return; fi
  local P; if [ $pile = u ] || [ $pile = e ]; then P="food=400 refill=400"; else P="food=30 refill=6000"; fi
  if [ $ft = unset ]; then unset PIXEL_PHYSICS_FOOD_TRAIL; else export PIXEL_PHYSICS_FOOD_TRAIL=$ft; fi
  ../tf-s1d mode=gap gate=shipped frames=24000 near=10 ants=$ants arms=$A gaps=$gap $P seeds=8 seed0=$s0 $extra > $f 2>&1
  echo "$name exit $? $(date +%H:%M)"; }
export -f job
T="decisioncsv dwide btrail btrailevery=100 cf=gate shadow decisiondir=/home/user/runs/s1d/csv"
{
  echo "id-lay unset self 90 u 1 20 dtag=s1lay_$T"
  echo "id-off off self 90 u 1 20 dtag=s1off_$T"
  for s in 1 9 17; do for g in 90 140; do for p in u p; do
    echo "mute-$g-$p-$s unset mute $g $p $s 20 -"; echo "muteoff-$g-$p-$s off mute $g $p $s 20 -"; done; done; done
  for s in 1 9 17; do echo "mute-135-e-$s unset mute 135 e $s 80 -"; echo "muteoff-135-e-$s off mute 135 e $s 80 -"; done
} > jobs.txt
# extra args: '-' is none; '_' separates dtag from the trace flags
sed -i 's/ -$/ /' jobs.txt
while read -r name ft A gap pile s0 ants extra; do echo "$name $ft $A $gap $pile $s0 $ants \"${extra//_/ }\""; done < jobs.txt > jobs2.txt
xargs -P 4 -L 1 bash -c 'job "$@"' _ < jobs2.txt
echo mute-done
