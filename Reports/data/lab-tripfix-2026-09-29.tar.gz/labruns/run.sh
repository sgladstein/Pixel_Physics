#!/bin/bash
cd /home/user/Pixel_Physics
export RAYON_NUM_THREADS=1
unset PIXEL_PHYSICS_COLONY_SPACING PIXEL_PHYSICS_STACK_DEPTH PIXEL_PHYSICS_BUD_SITE
unset PIXEL_PHYSICS_TRIP_REACH PIXEL_PHYSICS_RETURN_WINDOW
date -Is > /home/user/labruns/START
for N in $(seq 1 24); do
  ./target/release/examples/labforage scenario=played_bed frames=120000 seed=$N > /home/user/labruns/fix-$N.log 2>&1 &
  while [ "$(pgrep -x labforage | wc -l)" -ge 4 ]; do sleep 5; done
done
wait
date -Is > /home/user/labruns/DONE
