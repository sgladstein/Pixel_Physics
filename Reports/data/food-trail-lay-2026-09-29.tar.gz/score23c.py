#!/usr/bin/env python3
"""Score ant-scenes §23c (Stage 1, lay) from runs/s1: P1.1, P1.2 from the traced
logs' BTRAIL rows; P1.6, P1.7 and the harm bars from every log via the §22v
pairing. P1.3-P1.5 come from trailclimb.py / departures.py / giveup.py (run
separately). Row 95 (surface+1), late half (frame > 12000)."""
import re, sys, math, glob, statistics as st, collections
D = '/home/user/runs/s1'
LATE = 12000; ROW = 95
def sign3(a, b):
    hi = sum(y > x for x, y in zip(a, b)); lo = sum(y < x for x, y in zip(a, b)); n, k = hi + lo, min(hi, lo)
    p = min(1, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1
    return hi, lo, p
def btrail(path, want):
    """(seed, gap) -> mean profile over late samples for rows matching want(kv)."""
    acc = {}; meta = {}
    for line in open(path):
        if not line.startswith('BTRAIL '): continue
        kv = dict(t.split('=', 1) for t in line.split()[1:])
        if int(kv['frame']) <= LATE or not want(kv): continue
        k = (int(kv['seed']), int(kv['gap']), int(kv['y']))
        p = list(map(int, kv['prof'].split(',')))
        s, n = acc.get(k, ([0.0] * len(p), 0)); acc[k] = ([a + b for a, b in zip(s, p)], n + 1)
        meta[(k[0], k[1])] = (int(kv['x0']), int(kv['nest']), int(kv['target']))
    return {k: [v / n for v in s] for k, (s, n) in acc.items()}, meta
def pearson(a, b):
    ma, mb = st.mean(a), st.mean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b)); den = math.sqrt(sum((x - ma) ** 2 for x in a) * sum((y - mb) ** 2 for y in b))
    return num / den if den else float('nan')
print('P1.1 / P1.2 (traced seeds 1-8, unlimited pile)')
for g in (90, 140):
    offcf, meta = btrail(f'{D}/logs/off-{g}-u-1.log', lambda kv: kv['kind'] == 'cf' and kv['rule'] == 'gate' and kv['ch'] == 'B')
    offlive, _ = btrail(f'{D}/logs/off-{g}-u-1.log', lambda kv: kv['kind'] == 'live' and kv['ch'] == 'B')
    laylive, lmeta = btrail(f'{D}/logs/lay-{g}-u-1.log', lambda kv: kv['kind'] == 'live' and kv['ch'] == 'B')
    seeds = sorted({k[0] for k in laylive})
    print(f'  gap {g}: keys off-cf {len(offcf)} off-live {len(offlive)} lay-live {len(laylive)} seeds {seeds}')
    r_ok = w_ok = 0
    for s in seeds:
        r = pearson(laylive[(s, g, ROW)], offcf[(s, g, ROW)])
        x0, nest, tgt = meta[(s, g)]; nlo = nest - 2
        west = lambda P: sum(sum(P[(s, g, y)][: nlo - x0]) for y in range(ROW - 4, ROW + 1))
        wl, wo = west(laylive), west(offlive)
        frac = wl / wo if wo else float('nan')
        r_ok += r >= 0.8; w_ok += frac <= 0.10
        print(f'    seed {s}: r(lay live, off cf=gate) {r:+.3f}   west-of-door B lay/off {wl:9.0f}/{wo:9.0f} = {frac:.3f}')
    print(f'  gap {g}: P1.1 r >= 0.8 on {r_ok}/{len(seeds)} (bar 6/8); P1.2 west <= 10% on {w_ok}/{len(seeds)} (bar 7/8)')
# Outcomes: the §22v pairing parser, over all seeds per (arm, gap, pile).
sys.argv = ['x', '/dev/null', '/dev/null']
src = open(f'{D}/v22/bedpair2.py').read().split('A, B = parse(')[0]
exec(src)
def load(arm, g, pile):
    out = {}
    for f in sorted(glob.glob(f'{D}/logs/{arm}-{g}-{pile}-*.log')):
        out.update(parse(f))
    return out
def burn(arm, g, pile):
    out = {}
    for f in sorted(glob.glob(f'{D}/logs/{arm}-{g}-{pile}-*.log')):
        pend = None; key = None
        for line in open(f):
            m = re.search(r'BURN \(J\).*trail laying (\d+)', line)
            if m: pend = int(m.group(1))
            m = re.match(r'^\s+(\d+)\s+(\d+)\s+(?:self|mute|hand)\s', line)
            if m and pend is not None: out[(int(m.group(1)), int(m.group(2)))] = pend; pend = None
    return out
print('\nOUTCOMES (paired within seed; hi/lo counts are "second arm higher / lower")')
for pile in ('u', 'p'):
    for g in (90, 140):
        R = {a: load(a, g, pile) for a in ('off', 'lay', 'mute')}
        print(f'  pile {pile} gap {g}: runs off {len(R["off"])} lay {len(R["lay"])} mute {len(R["mute"])}')
        for a, b in (('off', 'lay'), ('mute', 'lay'), ('off', 'mute')):
            K = sorted(set(R[a]) & set(R[b]))
            for q in ('taken', 'starved', 'born', 'nestfood'):
                ks = [k for k in K if q in R[a][k] and q in R[b][k]]
                if not ks: continue
                xa = [R[a][k][q] for k in ks]; xb = [R[b][k][q] for k in ks]
                hi, lo, p = sign3(xa, xb)
                print(f'    {a:>4} -> {b:<4} {q:9} n {len(ks):2}  total {sum(xa):>10.0f} -> {sum(xb):>10.0f}  median {st.median(xa):>9.1f} -> {st.median(xb):>9.1f}  {b} higher {hi}/{lo} p {p:.3f}')
        if pile == 'u':
            Bo, Bl = burn('off', g, pile), burn('lay', g, pile)
            K = sorted(set(Bo) & set(Bl)); hi, lo, p = sign3([Bo[k] for k in K], [Bl[k] for k in K])
            print(f'    P1.7 trail-laying J off -> lay: {sum(Bo[k] for k in K)} -> {sum(Bl[k] for k in K)}; lay lower on {lo}/{len(K)} (bar 22/24)')
