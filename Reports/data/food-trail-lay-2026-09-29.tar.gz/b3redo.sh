#!/bin/bash
cd /home/user/runs/s1
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
unset PIXEL_PHYSICS_FOOD_TRAIL
../tf-s1a mode=gap gate=shipped frames=24000 near=10 ants=80 food=400 refill=400 arms=mute gaps=135 seeds=8 seed0=17 > logs/mute-135-e-17.log 2>&1
echo "mute 135 e 17 exit $? $(date +%H:%M)"
echo b3redo-done
