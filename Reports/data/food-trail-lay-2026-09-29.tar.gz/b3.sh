#!/bin/bash
# B3: 80 founders at 135, off / lay / mute, seeds 1-24 (tf-s1a).
cd /home/user/runs/s1
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
job() { local arm=$1 s0=$2; local A=self
  if [ $arm = lay ]; then export PIXEL_PHYSICS_FOOD_TRAIL=lay; else unset PIXEL_PHYSICS_FOOD_TRAIL; fi
  [ $arm = mute ] && A=mute
  ../tf-s1a mode=gap gate=shipped frames=24000 near=10 ants=80 food=400 refill=400 arms=$A gaps=135 seeds=8 seed0=$s0 > logs/$arm-135-e-$s0.log 2>&1
  echo "$arm 135 e $s0 exit $? $(date +%H:%M)"; }
export -f job
for s in 1 9 17; do for a in off lay mute; do echo "$a $s"; done; done | xargs -P 4 -L 1 bash -c 'job "$@"' _
echo b3-done
