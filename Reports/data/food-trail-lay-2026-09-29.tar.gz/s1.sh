#!/bin/bash
# Stage 1 (lay) on the colony bed, frozen binary tf-s1a. Registered in
# ant-scenes §23c before this ran. Jobs: arm gap pile seed0 [trace]
cd /home/user/runs/s1
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
job() { local arm=$1 gap=$2 pile=$3 s0=$4 tr=$5
  local P; if [ $pile = u ]; then P="food=400 refill=400"; else P="food=30 refill=6000"; fi
  local A=self ft=""; case $arm in off) ;; lay) ft=lay;; mute) A=mute;; esac
  local T=""; if [ -n "$tr" ]; then T="decisioncsv dwide dtag=s1$arm btrail btrailevery=100 cf=gate shadow"; fi
  local tag=$arm-$gap-$pile-$s0
  if [ -n "$ft" ]; then export PIXEL_PHYSICS_FOOD_TRAIL=$ft; else unset PIXEL_PHYSICS_FOOD_TRAIL; fi
  ../tf-s1a mode=gap gate=shipped frames=24000 near=10 ants=20 arms=$A gaps=$gap $P seeds=8 seed0=$s0 $T > logs/$tag.log 2>&1
  echo "$tag exit $? $(date +%H:%M)"
}
export -f job
mkdir -p logs
{
  for g in 90 140; do for a in off lay; do echo "$a $g u 1 t"; done; done
  for g in 90 140; do for a in mute; do echo "$a $g u 1"; done; done
  for s in 9 17; do for g in 90 140; do for a in off lay mute; do echo "$a $g u $s"; done; done; done
  for s in 1 9 17; do for g in 90 140; do for a in off lay mute; do echo "$a $g p $s"; done; done; done
} > jobs.txt
xargs -P 4 -L 1 bash -c 'job "$@"' _ < jobs.txt
mkdir -p csv1 && mv /tmp/trailfollow-decisions-seed*-self-s1off.csv /tmp/trailfollow-decisions-seed*-self-s1lay.csv csv1/ 2>/dev/null
echo s1-done
