#!/bin/bash
# Stage 1 identity: FOOD_TRAIL unset and =off against the Stage 0 binary, and
# mute under lay against mute unset.
cd /home/user/runs/s1
export RAYON_NUM_THREADS=1 PIXEL_PHYSICS_COLONY_SPACING=2 PIXEL_PHYSICS_STACK_DEPTH=4 PIXEL_PHYSICS_BUD_SITE=nest
B="mode=gap gate=shipped frames=24000 near=10 gaps=90 ants=20 food=30 refill=6000 seeds=8 seed0=1"
( ../tf-s1a $B arms=self decisioncsv dtag=s1unset > unset.log 2>&1; echo "unset $?" ) &
( PIXEL_PHYSICS_FOOD_TRAIL=off ../tf-s1a $B arms=self decisioncsv dtag=s1off > off.log 2>&1; echo "off $?" ) &
( ../tf-s1a mode=gap gate=shipped frames=24000 near=10 gaps=90,140 ants=20 food=400 refill=400 seeds=4 seed0=1 arms=mute > mute-unset.log 2>&1; echo "mute-unset $?" ) &
( PIXEL_PHYSICS_FOOD_TRAIL=lay ../tf-s1a mode=gap gate=shipped frames=24000 near=10 gaps=90,140 ants=20 food=400 refill=400 seeds=4 seed0=1 arms=mute > mute-lay.log 2>&1; echo "mute-lay $?" ) &
wait
mkdir -p csv && mv /tmp/trailfollow-decisions-seed*-gap90-self-s1unset.csv /tmp/trailfollow-decisions-seed*-gap90-self-s1off.csv csv/ 2>/dev/null
echo id-done
