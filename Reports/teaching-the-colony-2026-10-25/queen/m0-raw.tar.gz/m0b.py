import glob,random,statistics as st,collections
rng=random.Random(7)
for w in ("0.03,1,10","0.1,1,30","0.3,2,100"):
    ants=[]
    for f in glob.glob(f'w{w}_s*.txt'):
        for l in open(f):
            if l.startswith('ANT'):
                d=dict(kv.split('=') for kv in l.split()[1:])
                ants.append((int(d['member']),int(d['frames']),int(d['digs']),int(d['trips']),int(d['offspring'])))
    ctl=[a for a in ants if a[0]<10]
    def rate(rows,i): 
        fr=sum(a[1] for a in rows); return 1000*sum(a[i] for a in rows)/max(fr,1)
    c_t,c_d=rate(ctl,3),rate(ctl,2)
    c_off=sum(a[4] for a in ctl)/10
    out=collections.Counter(); lines=[]
    for m in range(10,30):
        rows=[a for a in ants if a[0]==m]
        n=len(rows)
        t,dg=rate(rows,3),rate(rows,2); off=sum(a[4] for a in rows)
        # bootstrap band of control at size n
        bt=[];bd=[]
        for _ in range(400):
            s=[rng.choice(ctl) for _ in range(n)]
            bt.append(rate(s,3)); bd.append(rate(s,2))
        bt.sort(); bd.sort()
        cls='ordinary'
        if t<0.5*c_t: cls='broken-forager'
        elif t>bt[389] or dg>bd[389]: cls='jewel'
        out[cls]+=1
        lines.append(f"  m{m} n={n} trips_pk={t:.2f} (band {bt[10]:.2f}-{bt[389]:.2f}) digs_pk={dg:.2f} (band {bd[10]:.2f}-{bd[389]:.2f}) offspring={off} {cls}")
    print(f"width {w}: control trips_pk={c_t:.2f} digs_pk={c_d:.2f} offspring/label={c_off:.0f}  classes={dict(out)}")
    print("\n".join(lines))
