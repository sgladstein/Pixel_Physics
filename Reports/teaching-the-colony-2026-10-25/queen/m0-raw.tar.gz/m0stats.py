import glob,random,statistics as st,sys
ants=[]  # (seed, member, frames, digs, del, offspring)
for f in glob.glob('s*.txt'):
    sd=int(f[1:-4])
    for l in open(f):
        if l.startswith('ANT'):
            d=dict(kv.split('=') for kv in l.split()[1:])
            ants.append((sd,int(d['member']),int(d['frames']),int(d['digs']),int(d['deliveries']),int(d['offspring']),int(d['trips'])))
MINF=int(sys.argv[1]) if len(sys.argv)>1 else 3000
live=[a for a in ants if a[2]>=MINF]
def rates(rows,idx):
    by={}
    for a in rows:
        by.setdefault(a[1],[0,0,0])
        by[a[1]][0]+=a[2]; by[a[1]][1]+=a[idx]; by[a[1]][2]+=1
    return {m:(v[1]*1000/v[0],v[2]) for m,v in by.items() if v[2]>=8}
for name,idx in (('digs',3),('deliveries',4),('trips',6)):
    r=rates(live,idx)
    vals=[v[0] for m,v in r.items() if m not in (5,)]
    obs=st.pstdev(vals)
    # permutation null: shuffle member labels among ants within seed
    null=[]
    rng=random.Random(1)
    for _ in range(300):
        perm=[]
        byseed={}
        for a in live: byseed.setdefault(a[0],[]).append(a)
        for sd,rows in byseed.items():
            ms=[a[1] for a in rows]; rng.shuffle(ms)
            perm+= [(a[0],m)+a[2:] for a,m in zip(rows,ms)]
        rr=rates(perm,idx)
        null.append(st.pstdev([v[0] for m,v in rr.items() if m!=5]))
    null.sort()
    print(f"{name}: members with>=8 ants: {len(r)}; between-member SD {obs:.3f}; null median {null[150]:.3f} p95 {null[285]:.3f}; p={sum(1 for x in null if x>=obs)/300:.3f}")
    top=sorted(r.items(),key=lambda kv:-kv[1][0])
    print("   top", [(m,round(v[0],2),v[1]) for m,v in top[:4]], "bottom", [(m,round(v[0],2),v[1]) for m,v in top[-4:]])
    print("   twin m0 vs m30:", r.get(0), r.get(30), " ablated m5:", r.get(5))
print("ants total", len(ants), "past", MINF, "frames:", len(live))
